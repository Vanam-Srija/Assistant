sap.ui.define(["sap/ui/core/mvc/Controller"],s=>{"use strict";return s.extend("sap.assistant.assistant.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map